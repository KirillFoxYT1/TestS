﻿var changeNumberPlate = new Vue({
    el: ".changenumberplate",
    data: {
        active: true,
		currentTab: 0,
		header: "СМЕНА НОМЕРОВ",
		text_1: "Персонализируйте свои номерные знаки",
		text_2: "В вашей любимой поездке чего-то не хватает? Создайте номерной знак, выберите автомобиль для установки.",
		// category: [
			// "Категория 1",
			// "Категория 2",
			// "Категория 2",
			// "Категория 2",
			// "Категория 2",
			// "Категория 2",
		// ], 
		items: [
			// [
			  // {type: 4, title: 'Монтировка', price: 150},
			  // {type: 5, title: 'Молоток', price: 150},
			  // {type: 6, title: 'Гаечный ключ', price: 150},
			  // {type: 7, title: 'Канистра бензина', price: 150},
			  // {type: 8, title: 'Связка ключей', price: 150}
			// ],
			// [
			  // {type: 4, title: 'Монтировка', price: 150},
			  // {type: 5, title: 'Молоток', price: 150},
			// ],
			// [
			  // {type: 6, title: 'Гаечный ключ', price: 150},
			  // {type: 7, title: 'Канистра бензина', price: 150},
			  // {type: 8, title: 'Связка ключей', price: 150}
			// ],
			// [
			  // {type: 6, title: 'Гаечный ключ', price: 150},
			  // {type: 8, title: 'Связка ключей', price: 150}
			// ]
		],
		basket: [ ],
    },
    methods: {
        current: function(id){
            this.currentTab = id;
        },
		buy: function(index) {
			mp.events.call('menu', 'shop', index);
		},
		exit: function() {
			mp.events.call('Close_new_shop');
		}
    }
})